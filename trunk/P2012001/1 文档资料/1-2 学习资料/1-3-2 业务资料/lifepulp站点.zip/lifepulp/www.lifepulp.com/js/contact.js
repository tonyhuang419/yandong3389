window.addEvent('domready', function() {

	// Expand footer content on mouseOver
	if($('confirmClose')) $('confirmClose').addEvent('click', function() {
				
					$('confirm').slide('out');
				}
				);


	$('submit').set('disabled', 'disabled');
	$('submitTxt').set("html", "You cannot submit the form yet.<br>Mandatory fields have not yet been filled out.");
	
	
	$('contactForm').addEvent("keyup", function() {
		
		var name = getValue("name");
		var email = getValue("email");
		var subject = getValue("subject");
		var message = getValue("message");
		
		var errors = true;
		if(validate("text", "name", name, false)) errors = false;
		if(validate("text", "subject", subject, false)) errors = false;
		if(validate("text", "message", message, false)) errors = false;
		
		if(validate("email", "email", email, false)){
			errors = false;
			$('invalidEmail').set("html", "Invalid E-mail.");
		} else { $('invalidEmail').set("html", ""); }
		
		
		if(errors) {
				
				$('submit').set('disabled', '');
				$('submitTxt').set("html", "").setStyle("border", "0");
							
				
			} else {
				$('submit').set('disabled', 'disabled');
				$('submitTxt').set("html", "Your form is incomplete! Fields are empty, invalid, or too short. Make sure you fill in all the fields.");
			}
		
	});
	
	$('contactForm').fireEvent('keyup');
	
	function getValue(item) {
		return $(item).get('value');
	};
	
	function setValue(item, color) {
		return $(item).setStyle('border-left', "6px solid "+color);
	};
	
	function validate(type, item, value, value2) {
		
		var pass = false;
		if(type == "text") {
			if(value.length > 1) {
				setValue(item, "#01cf14");
				pass = true;
			} else { setValue(item, "#FF0000"); }
		}
		else if(type == "email") {
			
			if(value.length > 7 && value.contains('@') && value.contains('.') && value != "" && value != " ") {
						setValue("email", "#01cf14");
						pass = true;
					} else { 
						setValue("email", "#FF0000");
					}	
				
			
		}
		else if(type == "email2") {
			
			if(value == value2 && value2 != "") {
				setValue("email2", "#01cf14");
				pass = true;
			} else { 
				setValue("email2", "#FF0000");
				}
			
		}
		else if(type == "email3") {
			
			if(value.length > 7 && value.contains('@') && value.contains('.') && value != "" && value != " ") {
					var joinData = new Request.JSON({
					url: '/joinData.php',
					method: 'get',
					onComplete: function(data){
						if(data != 0) {
							$('invalidEmail').set("html", "E-mail already registered.");
							setValue("email", "#FF0000");
						}
					}
				}).get({'key': value, 'item': 'edit'});
			}
			
			

			
			
			
		}
		else if(type == "password") {
			
			if(value.length > 5 && value != "" && value != " ") {
				setValue("pass", "#01cf14");
				pass = true;
			} else { 
				setValue("pass", "#FF0000");
				}
			
		}
		else if(type == "password2") {
			
			if(value == value2 && value2 != "") {
				setValue("pass2", "#01cf14");
				pass = true;
			} else { 
				setValue("pass2", "#FF0000");
				}
			
		}
		if(pass) return false;
		else return true;
	}
	
});