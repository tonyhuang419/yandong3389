window.addEvent('domready', function() {

	
	$('submit').set('disabled', 'disabled');
	$('submitTxt').set("html", "You cannot submit the form yet.<br>Mandatory fields have not yet been filled out.");
	
	
	$('signupForm').addEvent("keyup", function() {
		
		var fname = getValue("fname");
		var lname = getValue("lname");
		var email = getValue("email");
		var email2 = getValue("email2");
		var pass = getValue("pass1");
		var pass2 = getValue("pass2");
		//var terms = getValue("pass2");
		
		
		
		var errors = true;
		
		
		
		if(validate("text2", "fname", fname, false)){
			errors = false;
			$('invalidfname').set("html", "Please enter (letters only).");
		} else { $('invalidfname').set("html", ""); }

		if(validate("text2", "lname", lname, false)){
			errors = false;
			$('invalidlname').set("html", "Please enter (letters only).");
		} else { $('invalidlname').set("html", ""); }

		//if(validate("text", "fname", fname, false)) errors = false;
		//if(validate("text", "lname", lname, false)) errors = false;

		if(validate("email", "email", email, false)){
			errors = false;
			$('invalidEmail').set("html", "Invalid E-mail.");
		} else { $('invalidEmail').set("html", ""); }
		
		validate("email3", "email", email, false)
		
		if($('invalidEmail').get("html") == "E-mail already registered."){
			errors = false;
		}
		
		if(validate("email2", "email", email, email2)) {
			errors = false;
			$('mismatchEmail').set("html", "E-mails don't match.");
		} else { $('mismatchEmail').set("html", ""); }
		
		if(validate("password", "pass", pass, false)) {
			errors = false;
			$('invalidPass').set("html", "At least 7 characters.");
		} else { $('invalidPass').set("html", ""); }

		if(validate("password2", "pass", pass, pass2)) {
			errors = false;
			$('mismatchPass').set("html", "Passwords don't match.");
		} else { $('mismatchPass').set("html", ""); }
				
		
		if(errors) {
				
				$('submit').set('disabled', '');
				$('submitTxt').set("html", "").setStyle("border", "0");
							
				
			} else {
				$('submit').set('disabled', 'disabled');
				$('submitTxt').set("html", "Your form is incomplete! Fields are empty, invalid, or too short. Make sure you fill in all the fields.");
			}
		
	});
	
	$('signupForm').fireEvent('keyup');
	
	function getValue(item) {
		return $(item).get('value');
	};
	
	function setValue(item, color) {
		return $(item).setStyle('border-left', "6px solid "+color);
	};
	
	function validate(type, item, value, value2) {
		
		var pass = false;
		if(type == "text") {
						
			if(value.length > 1) {
				setValue(item, "#01cf14");
				pass = true;
			} else { setValue(item, "#FF0000"); }
			 	
		}
		else if(type == "text2") {
		
			if(value.length > 1 && !value.contains('.') && !value.contains('@') && !value.contains('~') && !value.contains('_') && !value.contains('!') && !value.contains('?') && !value.contains('#') && !value.contains('%') && !value.contains('$') && !value.contains('^') && !value.contains('`') && !value.contains('(') && !value.contains(')') && !value.contains('{') && !value.contains('}') && !value.contains('[') && !value.contains(']') && !value.contains(';') && !value.contains(':') && !value.contains('"') && !value.contains('\'') && !value.contains('<') && !value.contains('>') && !value.contains(',') && !value.contains('|') && !value.contains('/') && !value.contains('\\') && !value.contains('+') && !value.contains('=') && !value.contains('*') && !value.contains('&')) {
				setValue(item, "#01cf14");
				pass = true;
			} else { setValue(item, "#FF0000"); }
		
		}
		else if(type == "email") {
			
			if(value.length > 7 && value.contains('@') && value.contains('.') && value != "" && value != " ") {
						setValue("email", "#01cf14");
						pass = true;
					} else { 
						setValue("email", "#FF0000");
					}	
				
			
		}
		else if(type == "email2") {
			
			if(value == value2 && value2 != "") {
				setValue("email2", "#01cf14");
				pass = true;
			} else { 
				setValue("email2", "#FF0000");
				}
			
		}
		else if(type == "email3") {
			
			if(value.length > 7 && value.contains('@') && value.contains('.') && value != "" && value != " ") {
					var joinData = new Request.JSON({
					url: '/joinData.php',
					method: 'get',
					onComplete: function(data){
						if(data != 0) {
							$('invalidEmail').set("html", "E-mail already registered.");
							setValue("email", "#FF0000");
						}
					}
				}).get({'key': value, 'item': 'all'});
			}
			
			

			
			
			
		}
		else if(type == "password") {
			
			if(value.length > 5 && value != "" && value != " ") {
				setValue("pass1", "#01cf14");
				pass = true;
			} else { 
				setValue("pass1", "#FF0000");
				}
			
		}
		else if(type == "password2") {
			
			if(value == value2 && value2 != "") {
				setValue("pass2", "#01cf14");
				pass = true;
			} else { 
				setValue("pass2", "#FF0000");
				}
			
		}
		if(pass) return false;
		else return true;
	}
	
});