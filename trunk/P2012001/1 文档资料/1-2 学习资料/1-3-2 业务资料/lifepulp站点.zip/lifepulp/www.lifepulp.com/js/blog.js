window.addEvent('domready', function() {
	
	if($('commentForm')) $('commentForm').addEvents({"keyup": function() {

		var comment = getValue("comment");
		var errors = true;
		if(validate("text", "comment", comment, false)) errors = false;
		
		if(errors) {
				
				$('submit').set('disabled', '');
				$('submitTxt').set("html", "").setStyle("border", "0");
							
				
			} else {
				
				$('submit').set('disabled', 'disabled');
				$('submitTxt').set("html", "Your comment must be longer than 2 characters.");
			}
		
	}, "submit": function() {
				
		if($('itemComment')) {
			var item = getValue('itemComment');		
		} else {
			var item = "no";
		}	
			var threaditem = "no";
		
		
		var comment = getValue("comment");
		if(comment.length > 1) {
			
				var commentData = new Request.JSON({
					url: '/commentData.php',
					method: 'get',
					onComplete: function(data){
					
					if($('nocomments')) $('nocomments').setStyle('display', 'none');
						
						if(data) {
						
							var photo = '/img/avatar.jpg';
							if(data.userphoto == "yes") photo = '/imgs/users/tiny/'+data.user_id+'.'+data.userphoto_ext;
							
							var currentComments = $('comments').get('html');
							var threadLocation = "off";
							if($("threadlocation")) threadLocation = "on";
							
							$('comments').set('html', '');
							
							if(threadLocation == "on") new Element('div').set('html', currentComments).inject($('comments', 'bottom'));
							
							new Element('div').set({'class': 'inspiration', 'id': 'comment'+data.comment_id}).setStyle('opacity', 0).inject($('comments', 'top'));
							
							new Element('div').set({'class': 'boxLeft', 'id': 'commentPhoto'+data.comment_id}).inject($('comment'+data.comment_id, 'top'));
							new Element('a').set({'href': '/profile/'+data.user_id, 'id': 'commentLink'+data.comment_id}).inject($('commentPhoto'+data.comment_id, 'bottom'));
							new Element('img').set({'class': 'avatar', 'src': photo}).inject($('commentLink'+data.comment_id, 'bottom'));
						
							new Element('div').set({'class': 'boxRight', 'id': 'commentRight'+data.comment_id}).inject($('comment'+data.comment_id, 'bottom'));
							
				
							
							new Element('span').set({'class': 'boxUserTitle', 'html': '<a href="/profile/'+data.user_id+'">'+data.name+'</a> commented:'}).inject($('commentRight'+data.comment_id, 'bottom'));
							new Element('div').set('class', 'boxTop').inject($('commentRight'+data.comment_id, 'bottom'));
							new Element('div').set({'class': 'box', 'html': data.comment}).inject($('commentRight'+data.comment_id, 'bottom'));
							new Element('div').set('class', 'boxBottom').inject($('commentRight'+data.comment_id, 'bottom'));
							
							new Element('div').set('class', 'clear').inject($('comment'+data.comment_id, 'bottom'));
							
							$('comment'+data.comment_id).tween('opacity', 1);
							
							$('commentBox').tween('opacity', 0);
							$('commentBox').setStyle('display', 'none');
							$('comment').set('value', '');
														
							if(threadLocation != "on") new Element('div').set('html', currentComments).inject($('comments', 'bottom'));
							
						}	
						
						
					}
				}).get({'comment': comment, 'item': item, 'threaditem': threaditem, 'for': 'blog'});

		
		
		}
		return false;

	}
	});
	
	$('submitTxt').setStyle('border-color', '#ffffff');	
	if($('submit')) $('submit').set('disabled', 'disabled');
	if($('commentBox')) $('commentBox').addEvent('click', function() {
		if($('submitTxt')) $('submitTxt').set("html", "Your comment must be longer than 3 characters.").setStyle('border-color', '#ff0000');
		if($('commentForm')) $('commentForm').fireEvent('keyup');
	});
	
	function getValue(item) {
		return $(item).get('value');
	};
	
	function setValue(item, color) {
		return $(item).setStyle('border-left', "6px solid "+color);
	};
	
	function validate(type, item, value, value2) {
		
		var pass = false;
		if(type == "text") {
			if(value.length > 1) {
				setValue(item, "#01cf14");
				pass = true;
			} else { setValue(item, "#FF0000"); }
		}
		else if(type == "email") {
			
			if(value.length > 7 && value.contains('@') && value.contains('.') && value != "" && value != " ") {
						setValue("email", "#01cf14");
						pass = true;
					} else { 
						setValue("email", "#FF0000");
					}	
				
			
		}
	
			
		

		if(pass) return false;
		else return true;
	};


	// Comment form hide/unhide
	if($('commentBoxHit')) {
	
		
	
		$('commentBoxHit').addEvent('click', function() {
			$('commentBoxHit').setStyle('display','none');
			$('commentBox').setStyle('display','block');
			$("comment").focus();
		});
		
	
	}
	


});