window.addEvent('domready', function() {
	
	
	if($('landingJoin')) {
	
		$('joinfirstname').addEvent('focus', function() {
							$('joinfirstname').set('value', '').setStyles({'color': '#707070', 'font-weight': 'bold', 'font-style': 'normal'});
						});
		$('joinemail').addEvent('focus', function() {
							$('joinemail').set('value', '').setStyles({'color': '#707070', 'font-weight': 'bold', 'font-style': 'normal'});
						});
		$('joinpass').addEvent('focus', function() {
							$('joinpass').set({'value': '', 'type': 'password'}).setStyles({'color': '#707070', 'font-weight': 'bold', 'font-style': 'normal'});
						});
	}

});