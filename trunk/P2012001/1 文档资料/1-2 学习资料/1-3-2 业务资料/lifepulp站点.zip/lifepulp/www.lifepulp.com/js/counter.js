window.addEvent('domready', function() {
	
	
	function swap_digit(counter_spot, new_value) {
	
		if($(counter_spot)) {
			var last_value = $(counter_spot).get('html');
			
			if(last_value != new_value) {
				$(counter_spot).setStyle('opacity', 0);
				$(counter_spot).set('html', new_value);
				$(counter_spot).tween('opacity', 1);
			}
		}
	
	};
	
	
	function update_counter() {
					var inspiredData = new Request.JSON({
					url: '/json/counter.json',
					method: 'get',
					onComplete: function(data){

						var counter = data.counter;
						counter = counter.replace(/\"/, "");
						var strlen = Number(counter.length);
						var empties = 9 - strlen;
						
						var inc = Number(0);
						while(inc <= (strlen - 1)) {
						
							swap_digit("c"+empties, counter.charAt(inc));
							empties++;
							inc++;
						}	

						
					}
				}).get({'item': 'counter'});
	};

	if($('c8')) {
		update_counter();
		var play = function slideshow() {
				
					update_counter();
			
			};
		var player = play.periodical(5000);
	}


});